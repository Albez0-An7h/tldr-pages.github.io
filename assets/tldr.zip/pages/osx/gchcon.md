# gchcon

> This command is an alias of GNU `chcon`.

- View documentation for the original command:

`tldr -p linux chcon`
