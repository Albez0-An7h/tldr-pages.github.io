# glogname

> This command is an alias of GNU `logname`.

- View documentation for the original command:

`tldr -p linux logname`
