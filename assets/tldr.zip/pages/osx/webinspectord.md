# webinspectord

> Relays commands between Web Inspector and remote targets like WKWebView.
> It should not be invoked manually.
> More information: <https://keith.github.io/xcode-man-pages/webinspectord.8.html>.

- Start the daemon:

`webinspectord`
