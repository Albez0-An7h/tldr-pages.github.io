# gchroot

> This command is an alias of GNU `chroot`.

- View documentation for the original command:

`tldr -p linux chroot`
