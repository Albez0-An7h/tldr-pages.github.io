# xsand

> Xsan file system management daemon. Provides services for the Xsan file system.
> It should not be invoked manually.
> More information: <https://developer.apple.com/support/downloads/Xsan-Management-Guide.pdf>.

- Start the daemon:

`xsand`
