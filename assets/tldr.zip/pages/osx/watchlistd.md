# watchlistd

> Manage the Apple TV app's watch list.
> It should not be invoked manually.
> More information: <https://keith.github.io/xcode-man-pages/watchlistd.8.html>.

- Start the daemon:

`watchlistd`
