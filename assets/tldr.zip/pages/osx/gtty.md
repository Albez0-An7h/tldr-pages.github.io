# gtty

> This command is an alias of GNU `tty`.

- View documentation for the original command:

`tldr -p linux tty`
