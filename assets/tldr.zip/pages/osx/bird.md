# bird

> This supports the syncing of iCloud and iCloud Drive.
> It should not be invoked manually.
> More information: <https://keith.github.io/xcode-man-pages/bird.8.html>.

- Start the daemon:

`bird`
