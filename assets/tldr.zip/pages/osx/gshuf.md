# gshuf

> This command is an alias of GNU `shuf`.

- View documentation for the original command:

`tldr -p linux shuf`
