# wwand

> USB WWAN device configuration daemon.
> It should not be invoked manually.
> More information: <https://keith.github.io/xcode-man-pages/wwand.8.html>.

- Start the daemon:

`wwand`
