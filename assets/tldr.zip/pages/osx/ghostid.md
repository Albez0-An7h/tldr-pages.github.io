# ghostid

> This command is an alias of GNU `hostid`.

- View documentation for the original command:

`tldr -p linux hostid`
