# watchdogd

> Works with the Watchdog KEXT to ensure that the system is healthy and running.
> It should not be invoked manually.
> More information: <https://keith.github.io/xcode-man-pages/watchdogd.8.html>.

- Start the daemon:

`watchdogd`
