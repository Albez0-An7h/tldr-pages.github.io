# symptomsd

> Provides services for `Symptoms.framework`.
> It should not be invoked manually.
> More information: <https://keith.github.io/xcode-man-pages/symptomsd.8.html>.

- Start the daemon:

`symptomsd`
