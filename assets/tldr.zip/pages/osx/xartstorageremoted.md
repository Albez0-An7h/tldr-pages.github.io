# xartstorageremoted

> The xART Remote Storage Daemon. Receives save/fetch requests from the CoProcessor.
> It should not be invoked manually.
> More information: <https://keith.github.io/xcode-man-pages/xartstorageremoted.8.html>.

- Start the daemon:

`xartstorageremoted`
