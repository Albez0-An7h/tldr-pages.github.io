# gls

> This command is an alias of GNU `ls`.

- View documentation for the original command:

`tldr -p linux ls`
