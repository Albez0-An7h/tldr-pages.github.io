# gdnsdomainname

> This command is an alias of GNU `dnsdomainname`.

- View documentation for the original command:

`tldr -p linux dnsdomainname`
