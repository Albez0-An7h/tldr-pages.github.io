# gsleep

> This command is an alias of GNU `sleep`.

- View documentation for the original command:

`tldr -p linux sleep`
