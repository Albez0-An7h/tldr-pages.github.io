# gfalse

> This command is an alias of GNU `false`.

- View documentation for the original command:

`tldr -p linux false`
