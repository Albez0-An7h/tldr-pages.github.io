# gsplit

> This command is an alias of GNU `split`.

- View documentation for the original command:

`tldr -p linux split`
