# grsh

> This command is an alias of GNU `rsh`.

- View documentation for the original command:

`tldr -p linux rsh`
