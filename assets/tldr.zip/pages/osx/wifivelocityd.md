# wifivelocityd

> XPC helper for performing system context actions for the WiFiVelocity framework.
> It should not be invoked manually.
> More information: <https://keith.github.io/xcode-man-pages/wifivelocityd.8.html>.

- Start the daemon:

`wifivelocityd`
