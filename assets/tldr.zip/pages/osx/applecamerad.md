# applecamerad

> Camera manager.
> It should not be invoked manually.
> More information: <https://www.theiphonewiki.com/wiki/Services>.

- Start the daemon:

`applecamerad`
