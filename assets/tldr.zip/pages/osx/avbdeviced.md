# avbdeviced

> A service for managing Audio Video Bridging (AVB) devices.
> It should not be invoked manually.
> More information: <https://keith.github.io/xcode-man-pages/avbdeviced.1.html>.

- Start the daemon:

`avbdeviced`
