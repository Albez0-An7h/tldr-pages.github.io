# appsleepd

> Start app sleep services.
> It should not be invoked manually.
> More information: <https://keith.github.io/xcode-man-pages/appsleepd.8.html>.

- Start the daemon:

`appsleepd`
