# systemsoundserverd

> Core Audio related daemon.
> It should not be invoked manually.

- Start the daemon:

`systemsoundserverd`
