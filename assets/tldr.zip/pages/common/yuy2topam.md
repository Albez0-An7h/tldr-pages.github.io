# yuy2topam

> Convert YUY2 bytes to PAM.
> More information: <https://netpbm.sourceforge.net/doc/yuy2topam.html>.

- Convert YUY2 bytes to PAM:

`yuy2topam -width {{value}} -height {{value}} {{path/to/file.yuy2}} > {{path/to/file.pam}}`
