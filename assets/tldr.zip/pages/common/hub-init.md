# hub init

> Initializes a new local Git repository.
> More information: <https://hub.github.com/hub-init.1.html>.

- Initialize a new local repository:

`hub init`
