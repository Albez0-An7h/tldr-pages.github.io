# wordgrinder

> Command-line word processor.
> More information: <https://cowlark.com/wordgrinder>.

- Start WordGrinder (loads a blank document by default):

`wordgrinder`

- Open a given file:

`wordgrinder {{path/to/file}}`

- Show the menu:

`<Alt> + M`
