# jetifier

> Jetifier AndroidX transition tool in npm format, with a react-native compatible style.
> More information: <https://github.com/mikehardy/jetifier>.

- Migrate project dependencies to the AndroidX format:

`jetifier`

- Migrate project dependencies from the AndroidX format:

`jetifier reverse`
